package com.capgemini;

public class TennisGame {

    public static void main(String args[]){

        PlayerA playerA;
        PlayerB playerB;




    }


}
