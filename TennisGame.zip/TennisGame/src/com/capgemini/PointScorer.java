package com.capgemini;

import static com.capgemini.Players.PLAYER_1;
import static com.capgemini.Players.PLAYER_2;
import com.capgemini.Players;

public class PointScorer {

    private static final int MIN_POINTS_TO_WIN = 4;
    private static final int MIN_DIFF_TO_WIN = 2;


    protected void addPoint(Players player) {

        Integer newScore = Integer.valueOf(getScore(player) + 1); // Use the supposed cache in Integer
        setScore(player, newScore);
    }


    protected Players chooseWinner() {
        // Game is won if a player's game
        // points > 4 and greater than or equals opponents game points + 2
        final int score1 = getScore(PLAYER_1);
        final int score2 = getScore(PLAYER_2);
        final int diff = score1 - score2;

        if (score2 >= MIN_POINTS_TO_WIN
                && diff <= -MIN_DIFF_TO_WIN) {
            return PLAYER_2;

        } else if (score1 >= MIN_POINTS_TO_WIN
                && diff >= MIN_DIFF_TO_WIN) {
            return PLAYER_1;
        }
        return null;
    }

    /**
     * Retrieves the points for each player in the current game.
     * The points are returned as a String and is aimed for display
     * purposes. It can contain the string representation of :
     *  - An enum value of TennisPoints if the game is standard
     *  - A integer value if the game is a tie-break
     * @param player
     */
    public String getCurrentPoints(Players player) {
        return getCurrentGame().getScore(player).toString();
    }



    /**
     * Called when a player scores a point. This method updates
     * the score for the current game, set and match.
     */

    public boolean scorePoint(Players player) {

        // If the set is finished, cannot score anymore
        if (isFinished()) {
            return false;
        }

        // Adds a new point to the player's score
        addPoint(player);

        // Check if a player just won the game
        checkFinished();

        return true;
    }



    public Players getWinner() {
        return match.getWinner();
    }


    public boolean checkFinished() {
        return match.checkFinished();
    }

    /**
     * Returns the score for the specified player
     * @param player
     * @return
     */
    public ScoreType getScore(Players player) {
        if (scores == null) {
            throw new IllegalArgumentException("Cannot get score for null player");
        }

        return scores.get(player);
    }

    public IntScores getScore() {
        return match.getScore();
    }

    /**
     * Retrieves the points for each player in the current game.
     * The points are returned as a String and is aimed for display
     * purposes. It can contain the string representation of :
     *  - An enum value of TennisPoints if the game is standard
     *  - A integer value if the game is a tie-break
     * @param player
     */
    public String getCurrentPoints(Players player) {
        return getCurrentGame().getScore(player).toString();
    }

    /**
     * Returns the points of both players in the current game.
     * @return The content of the returned object depends on the type of
     * game. If it's a tie-break, then the scores are Integer
     * objects ; otherwise, scores are expressed as TennisPoints enum values.
     */
    @SuppressWarnings("unchecked")
    public <T extends GameScores> T getCurrentPoints() {
        return (T)match.getCurrentGame().getScore();
    }


    /* Retrieves the number of games won by both players in the current set
     * @return
     */
    public IntScores getGamesWon() {
        return match.getScore();
    }

    /**
     * Indicates if the current game is in deuce
     * @return
     */
    public boolean isDeuce() {
        return match.getCurrentSet().getCurrentGame().isDeuce();
    }


    /**
     * Indicates if the match is finished
     * @return
     */
    public boolean isFinished() {
        return match.isFinished();
    }
}




